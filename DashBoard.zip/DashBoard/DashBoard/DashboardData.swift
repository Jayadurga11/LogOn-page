//
//  DashboardData.swift
//  DashBoard
//
//  Created by Rahul on 17/05/23.
//  Copyright © 2023 Rahul. All rights reserved.
//

import Foundation

class DashboardData {
    
    
       var SchoolImage:String
       var SchoolDescription:String
       var SchoolDate:String
    
     init(SImage: String,SDescription: String,SDate: String) {
           
           SchoolImage = SImage
           SchoolDescription = SDescription
           SchoolDate = SDate
           
    
    }
    
}
