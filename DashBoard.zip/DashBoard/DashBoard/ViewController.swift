//
//  ViewController.swift
//  DashBoard
//
//  Created by Rahul on 17/05/23.
//  Copyright © 2023 Rahul. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
     var listSchool = [DashboardData]()
    
    var listDashboardtableviewcell = [dashboardtableview]()
    
    

    
    @IBOutlet weak var userLbl: UILabel!
    
    @IBOutlet weak var userClass: UILabel!
    
    @IBOutlet weak var userFace: UIImageView!
    
    @IBOutlet weak var view1: UICollectionView!
    
    
    @IBOutlet weak var noticeLbl: UILabel!
    
    
    @IBOutlet weak var homework: UILabel!
    
    
    @IBOutlet weak var tableviewcell: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
         
               let School1 = DashboardData(SImage: "School", SDescription: " school is going for vacation in next month", SDate: "02 March 2020")
                      listSchool.append(School1)
               
               let School2 = DashboardData(SImage: "Laptop", SDescription: "Summer book fair at school campus in june", SDate: "02 March 2020")
               listSchool.append(School2)
        
                    
        
        let School3 = DashboardData(SImage: "BookLibrary", SDescription: "Summer book fair at library", SDate: "02 March 2020")
        listSchool.append(School3)
        

        
               let circle1 = dashboardtableview(cImage1: "School", cDescription1:"hindi writing 3pages", cLanguage1: "hindi / yesterday")
                      listDashboardtableviewcell.append(circle1)
               
               let circle2 = dashboardtableview(cImage1: "Laptop", cDescription1:"Excerise trignometery 1st tpoic", cLanguage1: "Maths / Today")
               listDashboardtableviewcell.append(circle2)
                    
        
        let circle3 = dashboardtableview(cImage1: "BookLibrary", cDescription1:" Test for history first version", cLanguage1: "socialscience / yesterday")
        listDashboardtableviewcell.append(circle3)
        
        
    
    }

    
    @IBAction func menubarBtn(_ sender: Any) {
        
        
          
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
              let viewController2 = storyBoard.instantiateViewController(withIdentifier: "ViewController2") as! ViewController2
          self.present(viewController2,animated: true,completion: nil)
        
        
        
    }
    
    
}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listSchool.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableviewcell.dequeueReusableCell(withIdentifier: "cell2", for: indexPath) as! TableViewCell
        
        cell.essayLbl.text = listSchool[indexPath.row].SchoolDescription
        cell.englishLbl.text = listSchool[indexPath.row].SchoolDate
        cell.circleImg.image = UIImage(named: listSchool[indexPath.row].SchoolImage)
        return cell
    }
    
    
}
extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listDashboardtableviewcell.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = view1.dequeueReusableCell(withReuseIdentifier: "cell1", for: indexPath) as! CollectionViewCell1
        
        cell.schoolDescription.text = listDashboardtableviewcell[indexPath.row].circleDescription1
        cell.schoolDate.text = listDashboardtableviewcell[indexPath.row].circleLanguage1
        cell.schoolLbl.image = UIImage(named:listDashboardtableviewcell[indexPath.row].circleImage1)
        return cell
        
    }
    
  
    
}
