//
//  ViewController2.swift
//  DashBoard
//
//  Created by Rahul on 17/05/23.
//  Copyright © 2023 Rahul. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    
    
    @IBOutlet weak var userFace2: UIImageView!
    
    @IBOutlet weak var userName: UILabel!
    
    @IBOutlet weak var userClass2: UILabel!
    
    @IBOutlet weak var crossImg: UIImageView!
    
    @IBOutlet weak var dashboardImg: UIImageView!
    
    @IBOutlet weak var dashboardLbl: UILabel!
    
    @IBOutlet weak var homeworkImg: UIImageView!
    
    @IBOutlet weak var homeworkLbl: UILabel!
    
    @IBOutlet weak var attendanceImg: UIImageView!
    
    
    @IBOutlet weak var attendanceLbl: UILabel!
    
    @IBOutlet weak var feedetailsImg: UIImageView!
    
    @IBOutlet weak var feedetailsLbl: UILabel!
    
    @IBOutlet weak var examinationImg: UIImageView!
    
    @IBOutlet weak var examinationLbl: UILabel!
    
    @IBOutlet weak var reportImg: UIImageView!
    
    @IBOutlet weak var reportLbl: UILabel!
    
    
    @IBOutlet weak var calendarImg: UIImageView!
    
    @IBOutlet weak var calendarLbl: UILabel!
    
    
    @IBOutlet weak var noticeImg: UIImageView!
    
    
    @IBOutlet weak var noticeLbl: UILabel!
    
    @IBOutlet weak var multiImg: UIImageView!
    
    @IBOutlet weak var multiLbl: UILabel!
    
    
    @IBOutlet weak var academicImg: UIImageView!
    
    @IBOutlet weak var academicLbl: UILabel!
    
    @IBOutlet weak var profileImg: UIImageView!
    
    @IBOutlet weak var profileLbl: UILabel!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func logoutBtn(_ sender: Any) {
        
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let viewController = storyBoard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        self.present(viewController,animated: true,completion: nil)
        
        
    }
    
}
