//
//  dashboardtableview.swift
//  DashBoard
//
//  Created by Rahul on 17/05/23.
//  Copyright © 2023 Rahul. All rights reserved.
//

import Foundation


class dashboardtableview {
    
    
       var circleImage1:String
       var circleDescription1:String
       var circleLanguage1:String
    
     init(cImage1: String,cDescription1: String,cLanguage1: String) {
           
           circleImage1 = cImage1
           circleDescription1 = cDescription1
           circleLanguage1 = cLanguage1
           
    
    }
    
}
