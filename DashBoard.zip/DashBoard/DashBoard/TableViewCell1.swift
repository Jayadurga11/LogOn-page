//
//  TableViewCell1.swift
//  DashBoard
//
//  Created by Rahul on 17/05/23.
//  Copyright © 2023 Rahul. All rights reserved.
//

import UIKit

class CollectionViewCell1: UICollectionViewCell {
    
    
    @IBOutlet weak var schoolLbl: UIImageView!
    
    
    @IBOutlet weak var schoolDescription: UILabel!
    
    
    @IBOutlet weak var schoolDate: UILabel!
    
    
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
        // Configure the view for the selected state
    }


